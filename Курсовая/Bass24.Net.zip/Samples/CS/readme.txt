C# Samples:
-----------
In order to run the samples the bass library and add-ons are needed.
These native bass libraries are nor included and need to be downloaded @ www.un4seen.com
The bass dlls needs to be copied to the startup directory first, e.g. .\bin\Debug

Here is a list of required bass libraries for the different samples

CreateFileUser:
---------------
bass.dll


Encoder:
--------
bass.dll
bassenc.dll
basswma.dll
bassmix.dll
lame.exe (e.g. download from www.rarewares.org)


NetRadio:
---------
bass.dll
basswma.dll


PlugIn:
-------
bass.dll
optional ALL bass add-ons in one directory


SetFX:
------
bass.dll


Simple:
-------
bass.dll


TestDSP:
---------
bass.dll
bass_fx.dll


SimpleAsio:
-----------
bass.dll
bassasio.dll


SimpleAsioFX:
-------------
bass.dll
bassasio.dll
bass_fx.dll


SimpleFX:
---------
bass.dll
bassasio.dll
bass_fx.dll


Streaming:
----------
bass.dll
bassenc.dll
basswma.dll
needs command-line encoders (e.g. download from www.rarewares.org)