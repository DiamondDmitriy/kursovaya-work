Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Audio Joiner")> 
<Assembly: AssemblyDescription("Combines MP3 Files into one MP3")> 
<Assembly: AssemblyCompany("ActiveASP Software")> 
<Assembly: AssemblyProduct("Audio Joiner")> 
<Assembly: AssemblyCopyright("Copyright � 2005 ActiveASP Software. All rights reserved.")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("20E29574-5E03-4FE6-ACEC-148C5954167A")>  
'<Assembly: AssemblyKeyFileAttribute("C:\activeasp.snk")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.0")> 
