VB Samples:
-----------
In order to run the samples the bass library and add-ons are needed.
These native bass libraries are nor included and need to be downloaded @ www.un4seen.com
The bass dlls needs to be copied to the startup directory first, e.g. .\bin

Here is a list of required bass libraries for the different samples

bassCDEx:
---------
bass.dll
basscd.dll


MP3Joiner:
----------
bass.dll
basswma.dll
bassmix.dll


StreamTest:
-----------
bass.dll


WaveForm:
---------
bass.dll
bass_fx.dll
basswma.dll
